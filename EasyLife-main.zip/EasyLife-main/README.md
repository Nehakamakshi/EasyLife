

Type the command in the console


1.npm init


2.npm install express


3.node main.js


Type localhost:3000 on browser


# Features


1.Contains multiple applications like:


a.Calculator


b.Paint


c.Notepad


d.Music Players


e.Chatbots


f.Youtube clone


g.Google Chrome Browser Clone


f.Todo List


g.Video Player


h.Weather


i.Video Player


j.Relaxer


k.Speech Recognizer


l.Your IMDB


m.Stone Paper Scissors


n.Voice Command


o.Quiz


p.Photo Editor


q.Budget Calculator


r.Secret Message


s.Voice Changer


![image](https://user-images.githubusercontent.com/63421456/96652059-c730a780-1353-11eb-81cd-329c3fa9533b.png)

![image](https://user-images.githubusercontent.com/63421456/96652088-d6aff080-1353-11eb-99b1-39a692db8881.png)

![image](https://user-images.githubusercontent.com/63421456/96652173-fe9f5400-1353-11eb-828d-26c4385ca504.png)

![image](https://user-images.githubusercontent.com/63421456/96652192-0a8b1600-1354-11eb-8879-9ebcb57ed5bb.png)

![image](https://user-images.githubusercontent.com/63421456/96652217-17a80500-1354-11eb-9ba8-5a2b2dbf619b.png)

![image](https://user-images.githubusercontent.com/63421456/96652243-22fb3080-1354-11eb-9750-cbf69059829a.png)

![image](https://user-images.githubusercontent.com/63421456/96652270-327a7980-1354-11eb-9cc8-4106b635fc9c.png)

![image](https://user-images.githubusercontent.com/63421456/96652298-3f976880-1354-11eb-9288-2684ff21654f.png)

![image](https://user-images.githubusercontent.com/63421456/96652322-4cb45780-1354-11eb-9c31-df03c72ea83f.png)

![image](https://user-images.githubusercontent.com/63421456/96652353-56d65600-1354-11eb-9f5b-7792ee95fd6e.png)

![image](https://user-images.githubusercontent.com/63421456/96652368-62c21800-1354-11eb-8aa6-70c9bfe71b0d.png)

![image](https://user-images.githubusercontent.com/63421456/96652388-6eadda00-1354-11eb-81bf-ea1db5a5909d.png)

![image](https://user-images.githubusercontent.com/63421456/96652404-766d7e80-1354-11eb-8bf3-83aaec123a3c.png)

![image](https://user-images.githubusercontent.com/63421456/96652431-808f7d00-1354-11eb-8c60-db2fee1c770d.png)

![image](https://user-images.githubusercontent.com/63421456/96652461-8f762f80-1354-11eb-8566-91598d996225.png)

![image](https://user-images.githubusercontent.com/63421456/96652517-af0d5800-1354-11eb-8790-800fffdb68e5.png)

![image](https://user-images.githubusercontent.com/63421456/96652535-b896c000-1354-11eb-921e-3184e7a11db7.png)

![image](https://user-images.githubusercontent.com/63421456/96652545-c0eefb00-1354-11eb-938b-2405dc201006.png)

![image](https://user-images.githubusercontent.com/63421456/96652558-ccdabd00-1354-11eb-80c0-57daf438cee9.png)

![image](https://user-images.githubusercontent.com/63421456/96652567-d401cb00-1354-11eb-806c-ffe3d50e7c45.png)

![image](https://user-images.githubusercontent.com/63421456/96652574-da904280-1354-11eb-9337-b7f8b6910f78.png)

![image](https://user-images.githubusercontent.com/63421456/96652602-e976f500-1354-11eb-8a47-945c4c35499c.png)

![image](https://user-images.githubusercontent.com/63421456/96652626-f09e0300-1354-11eb-8d5a-f5aea5778310.png)

![image](https://user-images.githubusercontent.com/63421456/96652652-fe538880-1354-11eb-8189-55abc32b1ae3.png)

![image](https://user-images.githubusercontent.com/63421456/96652702-13301c00-1355-11eb-8cfb-496c0d91674b.png)

